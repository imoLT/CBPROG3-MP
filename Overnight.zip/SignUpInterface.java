import java.awt.event.ActionEvent;

interface SignUpInterface {
    public void signUpMain();        
    public boolean isInputValid(); 
    public void actionPerformed(ActionEvent e);
}

/*

import java.awt.event.ActionEvent;

abstract class AbstractSignUp {
    public abstract void signUpMain();        
    public abstract boolean isInputValid(); 
    public abstract void actionPerformed(ActionEvent e);
	
	public void passwordReset(){
		//body here
	}
}

*/

