USE ProgMP;

SELECT *
FROM nonapprovedusers;

SELECT *
FROM users;

SELECT *
FROM rooms;

SELECT *
FROM unapprovebookings;

SELECT *
FROM approvedBookings;

