-- Drop the database if it exists
DROP DATABASE IF EXISTS ProgMP;

-- Create the new database
CREATE DATABASE ProgMP;

-- Switch to the newly created database
USE ProgMP;

-- Create the 'nonApprovedUsers' table with appropriate columns
CREATE TABLE nonApprovedUsers (
    id_number INT(8) PRIMARY KEY,  -- Use INT(8) for id_number
    password VARCHAR(255),
    role VARCHAR(50)
);

-- Create the 'users' table with 'idNumber' as INT(8)
CREATE TABLE IF NOT EXISTS users (
    idNumber INT(8) NOT NULL PRIMARY KEY,  -- Use INT(8) for idNumber
    password VARCHAR(255) NOT NULL,
    role ENUM('Program Admin', 'Professor', 'ITS', 'Security') NOT NULL
);

-- Insert default user (Program Admin)
INSERT INTO users (idNumber, password, role)
VALUES (12345678, 'password123', 'Program Admin');  -- Use INT(8) for idNumber

INSERT INTO users (idNumber, password, role)
VALUES (12344321, 'hi', 'Professor');  

-- Create the 'rooms' table
CREATE TABLE IF NOT EXISTS rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,  -- Unique identifier for each room
    category VARCHAR(255) NOT NULL,     -- Room category (e.g., Classroom, Laboratory)
    room_name VARCHAR(255) NOT NULL UNIQUE,  -- Unique name for each room
    max_capacity INT NOT NULL,         -- Maximum capacity of the room
    tags TEXT                          -- Additional tags for the room
);

-- Create 'unapproveBookings' table with professor_id as INT(8) to match 'users' table
CREATE TABLE approvedBookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    professor_id INT(8),  -- professor_id is INT(8), matching 'idNumber' in 'users'
    booking_date DATE,    -- Correct column name for the date
    time_slot VARCHAR(255),
    room_name VARCHAR(255),
    room_category VARCHAR(255),
    FOREIGN KEY (professor_id) REFERENCES users(idNumber)  -- Foreign key to 'users' table
);

CREATE TABLE IF NOT EXISTS unapproveBookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    professor_id INT,
    booking_date DATE,
    time_slot VARCHAR(255),
    room_name VARCHAR(255),
    room_category VARCHAR(255),
    FOREIGN KEY (professor_id) REFERENCES users(idNumber) -- Foreign key constraint
);

-- Add some example room data
INSERT INTO rooms (category, room_name, max_capacity, tags)
VALUES
    ('Classroom', 'MRE300', 30, 'whiteboard');
